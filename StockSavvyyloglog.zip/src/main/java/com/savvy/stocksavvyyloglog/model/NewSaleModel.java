package com.savvy.stocksavvyyloglog.model;

import java.time.LocalDate;

/**
 * Model class representing a single sale transaction.
 * Mirrors the Stock model pattern.
 */
public class NewSaleModel {

    private int       id;
    private String    customerName;
    private String    product;
    private int       quantity;
    private double    unitPrice;
    private double    discountPercent;
    private double    deliveryFee;
    private String    paymentMethod;
    private String    orderType;
    private LocalDate deliveryDate;
    private String    notes;

    // ── Constructors ──────────────────────────────────────────────────────────

    public NewSaleModel() {
        this.quantity        = 1;
        this.discountPercent = 0.0;
        this.deliveryFee     = 0.0;
        this.paymentMethod   = "Cash";
        this.orderType       = "pickup";
        this.deliveryDate    = LocalDate.now();
    }

    public NewSaleModel(String customerName, String product, int quantity,
                        double unitPrice, double discountPercent, double deliveryFee,
                        String paymentMethod, String orderType,
                        LocalDate deliveryDate, String notes) {
        this.customerName    = customerName;
        this.product         = product;
        this.quantity        = quantity;
        this.unitPrice       = unitPrice;
        this.discountPercent = discountPercent;
        this.deliveryFee     = deliveryFee;
        this.paymentMethod   = paymentMethod;
        this.orderType       = orderType;
        this.deliveryDate    = deliveryDate;
        this.notes           = notes;
    }

    // ── Computed ──────────────────────────────────────────────────────────────

    /** Returns the final total after discount and adding delivery fee. */
    public double getTotal() {
        double subtotal = unitPrice * quantity * (1.0 - discountPercent / 100.0);
        return subtotal + ("deliver".equals(orderType) ? deliveryFee : 0);
    }

    /** Basic validation — returns error string or empty if valid. */
    public String validate() {
        StringBuilder errors = new StringBuilder();
        if (customerName == null || customerName.trim().isEmpty())
            errors.append("• Customer name is required.\n");
        if (product == null || product.trim().isEmpty())
            errors.append("• Please select a product.\n");
        if (unitPrice <= 0)
            errors.append("• Unit price must be greater than zero.\n");
        if (orderType == null || orderType.trim().isEmpty())
            errors.append("• Order type is required.\n");
        if ("deliver".equals(orderType) && deliveryFee < 0)
            errors.append("• Delivery fee cannot be negative.\n");
        return errors.toString();
    }

    // ── Getters & Setters ─────────────────────────────────────────────────────

    public int       getId()                         { return id; }
    public void      setId(int id)                   { this.id = id; }

    public String    getCustomerName()               { return customerName; }
    public void      setCustomerName(String v)       { this.customerName = v; }

    public String    getProduct()                    { return product; }
    public void      setProduct(String v)            { this.product = v; }

    public int       getQuantity()                   { return quantity; }
    public void      setQuantity(int v)              { this.quantity = v; }

    public double    getUnitPrice()                  { return unitPrice; }
    public void      setUnitPrice(double v)          { this.unitPrice = v; }

    public double    getDiscountPercent()            { return discountPercent; }
    public void      setDiscountPercent(double v)    { this.discountPercent = v; }

    public double    getDeliveryFee()                { return deliveryFee; }
    public void      setDeliveryFee(double v)        { this.deliveryFee = v; }

    public String    getPaymentMethod()              { return paymentMethod; }
    public void      setPaymentMethod(String v)      { this.paymentMethod = v; }

    public String    getOrderType()                  { return orderType; }
    public void      setOrderType(String v)          { this.orderType = v; }

    public LocalDate getDeliveryDate()               { return deliveryDate; }
    public void      setDeliveryDate(LocalDate v)    { this.deliveryDate = v; }

    public String    getNotes()                      { return notes; }
    public void      setNotes(String v)              { this.notes = v; }

    @Override
    public String toString() {
        return String.format(
                "Sale{customer='%s', product='%s', qty=%d, price=₱%.2f, " +
                        "discount=%.1f%%, payment='%s', type='%s', delivery=%s, total=₱%.2f}",
                customerName, product, quantity, unitPrice,
                discountPercent, paymentMethod, orderType, deliveryDate, getTotal()
        );
    }
}